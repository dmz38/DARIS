<div id="header"  style="background-color: #07294D">
    <div class="row vertical-align">
        <div class="col-xs-5 col-sm-3 text-center">
            <img class="img-responsive" src="/img/ajlogo-clear.svg">
        </div>
        <div class="visible-xs col-xs-4 text-center">
            <h2>DARIS</h2>
        </div>
        <div class="hidden-xs col-sm-7 text-center">
            <h3><b>D</b>rexel <b>A</b>utism <b>R</b>esearch <b>I</b>nformation <b>S</b>ystem</h3>
        </div>
        <div class="visible-xs col-xs-3 text-center">
            <i class="fa fa-gear fa-2x" aria-hidden="true"></i>&nbsp;&nbsp;<i class="fa fa-sign-out fa-2x" aria-hidden="true"></i>
        </div>
        <div class="hidden-xs col-sm-2 text-center">
            <h4>Hi, <span id="logInUserName">Dan</span>!</h4>&nbsp;&nbsp;<i class="fa fa-gear fa-2x" aria-hidden="true"></i>&nbsp;&nbsp;<i class="fa fa-sign-out fa-2x" aria-hidden="true"></i>
        </div>

    </div>
</div>
