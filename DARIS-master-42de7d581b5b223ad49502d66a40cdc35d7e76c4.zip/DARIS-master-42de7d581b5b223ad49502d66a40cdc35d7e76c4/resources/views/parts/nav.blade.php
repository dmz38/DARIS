<div id="header"  style="background-color: #07294D">
    <div class="row vertical-align">
        <div class="col-xs-6 col-sm-3 text-center">
            <img class="img-responsive" src="/img/ajlogo-clear.svg">
        </div>
        <div class="visible-xs col-xs-6 text-center" style="color: white">
            <h2>DARIS</h2>
        </div>
        <div class="hidden-xs col-sm-9 text-center" style="color: white">
            <h2><b>D</b>rexel <b>A</b>utism <b>R</b>esearch <b>I</b>nformation <b>S</b>ystem</h2>
        </div>
    </div>
</div>
